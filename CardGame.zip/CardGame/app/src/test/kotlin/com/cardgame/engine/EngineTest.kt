package com.cardgame.engine

import kotlin.test.*

class ScoringTest {
    @Test fun predictionThreeTable() {
        val expected = mapOf(0 to -30, 1 to -30, 2 to -30, 3 to 30, 4 to 31, 5 to 32, 6 to -30, 7 to -30)
        expected.forEach { (a, s) -> assertEquals(s, Scoring.roundScore(3, a), "A=$a") }
    }
    @Test fun zeroPrediction() { (0..13).forEach { assertEquals(0, Scoring.roundScore(0, it)) } }
    @Test fun predictionOne() { assertEquals(10, Scoring.roundScore(1, 1)); assertEquals(-10, Scoring.roundScore(1, 2)) }
}

class DeckTest {
    @Test fun dealsAll52Unique() {
        val hands = Deck.deal(Deck.shuffled(), dealer = 2)
        assertTrue(hands.all { it.size == 13 })
        assertEquals(52, hands.flatten().toSet().size)
    }
}

class RulesTest {
    private fun c(s: Suit, v: Int) = Card(s, v)
    private fun p(seat: Int, s: Suit, v: Int) = Play(seat, c(s, v))
    private val T = Suit.SPADES

    @Test fun leaderPlaysAnything() {
        val h = listOf(c(Suit.HEARTS, 5), c(T, 2))
        assertEquals(h, Rules.legalCards(h, emptyList(), T))
    }
    @Test fun mustPlayHigherLedSuitIfPossible() {
        val h = listOf(c(Suit.HEARTS, 5), c(Suit.HEARTS, 12), c(T, 14))
        assertEquals(listOf(c(Suit.HEARTS, 12)), Rules.legalCards(h, listOf(p(0, Suit.HEARTS, 9)), T))
    }
    @Test fun followLowIfCannotBeat() {
        val h = listOf(c(Suit.HEARTS, 5), c(Suit.HEARTS, 6), c(T, 14))
        assertEquals(listOf(c(Suit.HEARTS, 5), c(Suit.HEARTS, 6)), Rules.legalCards(h, listOf(p(0, Suit.HEARTS, 9)), T))
    }
    @Test fun cannotTrumpWhenHoldingLedSuit() {
        val h = listOf(c(Suit.HEARTS, 3), c(T, 14))
        val trick = listOf(p(0, Suit.HEARTS, 9), p(1, T, 2))
        assertEquals(listOf(c(Suit.HEARTS, 3)), Rules.legalCards(h, trick, T))
    }
    @Test fun mustTrumpWhenVoid() {
        val h = listOf(c(Suit.CLUBS, 3), c(T, 4), c(T, 9))
        assertEquals(listOf(c(T, 4), c(T, 9)), Rules.legalCards(h, listOf(p(0, Suit.HEARTS, 9)), T))
    }
    @Test fun mustOvertrump() {
        val h = listOf(c(Suit.CLUBS, 3), c(T, 4), c(T, 9))
        val trick = listOf(p(0, Suit.HEARTS, 9), p(1, T, 6))
        assertEquals(listOf(c(T, 9)), Rules.legalCards(h, trick, T))
    }
    @Test fun lowerTrumpIfCannotOvertrump() {
        val h = listOf(c(Suit.CLUBS, 3), c(T, 4), c(T, 5))
        val trick = listOf(p(0, Suit.HEARTS, 9), p(1, T, 6))
        assertEquals(listOf(c(T, 4), c(T, 5)), Rules.legalCards(h, trick, T))
    }
    @Test fun anyCardIfNoLedNoTrump() {
        val h = listOf(c(Suit.CLUBS, 3), c(Suit.DIAMONDS, 4))
        assertEquals(h, Rules.legalCards(h, listOf(p(0, Suit.HEARTS, 9)), T))
    }
    @Test fun trickWinnerTrumpBeatsLed() {
        val t = listOf(p(0, Suit.HEARTS, 14), p(1, T, 2), p(2, Suit.HEARTS, 13), p(3, T, 3))
        assertEquals(3, Rules.trickWinner(t, T))
    }
    @Test fun trickWinnerLedSuitWhenNoTrump() {
        val t = listOf(p(0, Suit.HEARTS, 5), p(1, Suit.CLUBS, 14), p(2, Suit.HEARTS, 13), p(3, Suit.DIAMONDS, 14))
        assertEquals(2, Rules.trickWinner(t, T))
    }
    @Test fun firstLeaderTieBreakFromDealersLeft() {
        assertEquals(3, Rules.firstLeader(listOf(5, 2, 5, 5), dealer = 2)) // order checked: 3,0,1,2 -> seat 3
        assertEquals(0, Rules.firstLeader(listOf(5, 2, 5, 5), dealer = 3)) // order: 0,1,2,3 -> seat 0
    }
}
