package com.cardgame.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardgame.AppViewModel
import com.cardgame.Screen
import com.cardgame.net.ConnState
import com.cardgame.net.Phase
import com.cardgame.net.UiState

val Gold = Color(0xFFFFC107)
private val Felt1 = Color(0xFF0B3B2C)
private val Felt2 = Color(0xFF06231A)
private val Soft = Color(0xCCFFFFFF)

@Composable
fun Felt(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Felt1, Felt2))), content = content)
}

@Composable
fun GoldButton(text: String, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick, modifier = modifier, enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = Gold, contentColor = Color.Black,
            disabledContainerColor = Color(0x55FFC107), disabledContentColor = Color(0x99000000)
        )
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text(text) }
}

@Composable
fun App(vm: AppViewModel) {
    val ui by vm.ui.collectAsState()
    val nav by vm.nav.collectAsState()
    val ctx = LocalContext.current
    var showLeave by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.toasts.collect { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() } }

    val inSession = ui.phase != null &&
        (ui.conn == ConnState.ONLINE || ui.conn == ConnState.RECONNECTING || ui.conn == ConnState.HOST_LOST)
    BackHandler(enabled = inSession) { showLeave = true }
    BackHandler(enabled = !inSession && nav != Screen.Menu) { vm.cancelJoin(); vm.nav.value = Screen.Menu }

    Box(Modifier.fillMaxSize()) {
        if (inSession) {
            when (ui.phase) {
                Phase.LOBBY -> LobbyScreen(vm, ui) { showLeave = true }
                Phase.PREDICT, Phase.PLAY -> TableScreen(vm, ui) { showLeave = true }
                Phase.ROUND_END -> ResultsScreen(vm, ui) { showLeave = true }
                null -> {}
            }
            if (ui.conn == ConnState.RECONNECTING) {
                Overlay {
                    CircularProgressIndicator(color = Gold)
                    Spacer(Modifier.height(12.dp))
                    Text("Connection lost – reconnecting…", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Your seat and cards are kept.", color = Soft, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    GhostButton("Leave game") { showLeave = true }
                }
            }
            if (ui.conn == ConnState.HOST_LOST) {
                Overlay {
                    Text("Host unavailable", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        ui.notice + " The game cannot continue without the host. If the host app was closed, the round is lost; start a new room.",
                        color = Soft, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(12.dp))
                    GoldButton("Keep trying", modifier = Modifier.fillMaxWidth()) { vm.retry() }
                    GhostButton("Back to menu", modifier = Modifier.fillMaxWidth()) { vm.leave() }
                }
            }
        } else {
            when (nav) {
                Screen.Menu -> MenuScreen(vm)
                Screen.Join -> JoinScreen(vm, ui)
                Screen.HowTo -> RulesScreen { vm.nav.value = Screen.Menu }
                Screen.Settings -> SettingsScreen(vm) { vm.nav.value = Screen.Menu }
                Screen.History -> HistoryScreen(vm) { vm.nav.value = Screen.Menu }
            }
        }
        if (showLeave && inSession) {
            AlertDialog(
                onDismissRequest = { showLeave = false },
                title = { Text("Leave game?") },
                text = {
                    Text(if (ui.isHost) "You are the host: leaving ends the game for everyone." else "You will leave the room.")
                },
                confirmButton = { TextButton(onClick = { showLeave = false; vm.leave() }) { Text("Leave") } },
                dismissButton = { TextButton(onClick = { showLeave = false }) { Text("Stay") } }
            )
        }
    }
}

@Composable
private fun Overlay(content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(32.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF1B2B25)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, content = content
        )
    }
}

@Composable
fun MenuScreen(vm: AppViewModel) {
    val hasLast by vm.hasLastSession.collectAsState()
    Felt {
        Column(
            Modifier.fillMaxSize().padding(28.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Row {
                Text("♠", fontSize = 44.sp, color = Color.White)
                Text("♥", fontSize = 44.sp, color = Color(0xFFEF5350))
                Text("♣", fontSize = 44.sp, color = Color.White)
                Text("♦", fontSize = 44.sp, color = Color(0xFFEF5350))
            }
            Text("TRUMP CARDS", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Gold)
            Text("4-player prediction game · local Wi-Fi", color = Soft, fontSize = 14.sp)
            Spacer(Modifier.height(36.dp))
            GoldButton("Create Room", modifier = Modifier.fillMaxWidth().height(52.dp)) { vm.createRoom() }
            Spacer(Modifier.height(10.dp))
            GoldButton("Join Room", modifier = Modifier.fillMaxWidth().height(52.dp)) { vm.nav.value = Screen.Join }
            if (hasLast) {
                Spacer(Modifier.height(10.dp))
                GhostButton("Rejoin last game", Modifier.fillMaxWidth().height(48.dp)) { vm.rejoinLast() }
            }
            Spacer(Modifier.height(10.dp))
            GhostButton("Game Rules", Modifier.fillMaxWidth().height(48.dp)) { vm.nav.value = Screen.HowTo }
            Spacer(Modifier.height(10.dp))
            GhostButton("History & Leaderboard", Modifier.fillMaxWidth().height(48.dp)) { vm.nav.value = Screen.History }
            Spacer(Modifier.height(10.dp))
            GhostButton("Settings", Modifier.fillMaxWidth().height(48.dp)) { vm.nav.value = Screen.Settings }
        }
    }
}

@Composable
fun JoinScreen(vm: AppViewModel, ui: UiState) {
    val rooms by vm.rooms.collectAsState()
    var ip by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        vm.startDiscovery()
        onDispose { vm.stopDiscovery() }
    }
    val busy = ui.conn == ConnState.CONNECTING || ui.conn == ConnState.ONLINE
    Felt {
        Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { vm.cancelJoin(); vm.nav.value = Screen.Menu }) { Text("← Back", color = Gold) }
                Text("Join Room", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Text("Playing as ${vm.settings.value.name} (change in Settings)", color = Soft, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            if (ui.conn == ConnState.REJECTED) Text(ui.notice, color = Color(0xFFFF8A80))
            if (busy) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp), color = Gold, strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Connecting…", color = Color.White)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Rooms found on this Wi-Fi", color = Gold, fontWeight = FontWeight.Bold)
            if (rooms.isEmpty()) Text("Searching…  (if nothing appears, use manual entry below)", color = Soft, fontSize = 13.sp)
            for (r in rooms) {
                Surface(
                    shape = RoundedCornerShape(12.dp), color = Color(0x33FFFFFF),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { vm.joinRoom(r) }
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${r.hostName}'s room", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Room ${r.roomId} · ${r.slots} free slot(s)", color = Soft, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Manual entry", color = Gold, fontWeight = FontWeight.Bold)
            Text("Use the IP, port and room code shown in the host's lobby.", color = Soft, fontSize = 12.sp)
            OutlinedTextField(ip, { ip = it }, label = { Text("Host IP (e.g. 192.168.1.23)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(port, { port = it.filter(Char::isDigit).take(5) }, label = { Text("Port") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(code, { code = it.uppercase().take(4) }, label = { Text("Room code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            GoldButton("Connect", enabled = !busy, modifier = Modifier.fillMaxWidth()) { vm.joinManual(ip, port, code) }
        }
    }
}

@Composable
fun LobbyScreen(vm: AppViewModel, ui: UiState, onLeave: () -> Unit) {
    val info by vm.hostInfo.collectAsState()
    val allIn = (0..3).all { ui.seated[it] && ui.connected[it] }
    Felt {
        Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
            Text("Lobby", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Room ID", color = Soft, fontSize = 12.sp)
            Text(ui.roomId, fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Gold)
            Text("Host: ${ui.names[0]}", color = Color.White)
            info?.let {
                Text("Host address: ${it.ip}   Port: ${it.port}", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Other players find this room automatically. If they can't, they enter this IP, port and room code.", color = Soft, fontSize = 12.sp)
                if (it.ip == "unknown") Text("No Wi-Fi/hotspot address found – connect this phone to Wi-Fi.", color = Color(0xFFFF8A80), fontSize = 12.sp)
            }
            Spacer(Modifier.height(16.dp))
            for (s in 0..3) {
                val seated = ui.seated[s]
                val on = ui.connected[s]
                Surface(shape = RoundedCornerShape(12.dp), color = Color(0x33FFFFFF), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(12.dp).clip(CircleShape)
                                .background(if (seated && on) Color(0xFF4CAF50) else if (seated) Color(0xFFFFB300) else Color(0xFF757575))
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (seated) ui.names[s] + (if (s == 0) "  (host)" else "") + (if (s == ui.mySeat) "  (you)" else "") else "Waiting for player…",
                                color = Color.White, fontWeight = FontWeight.Bold
                            )
                            Text(if (!seated) "Seat ${s + 1} open" else if (on) "Connected" else "Disconnected", color = Soft, fontSize = 12.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            if (ui.isHost) {
                GoldButton("Start Game", enabled = allIn, modifier = Modifier.fillMaxWidth().height(52.dp)) { vm.startGame() }
                if (!allIn) Text("Needs all four players connected.", color = Soft, fontSize = 12.sp)
            } else {
                Text("Waiting for the host to start the game…", color = Soft)
            }
            Spacer(Modifier.height(8.dp))
            GhostButton("Leave", Modifier.fillMaxWidth()) { onLeave() }
        }
    }
}

@Composable
fun ResultsScreen(vm: AppViewModel, ui: UiState, onLeave: () -> Unit) {
    val r = ui.history.lastOrNull()
    Felt {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("Round ${r?.round ?: ui.round} results", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(12.dp))
            if (r != null) {
                Row(Modifier.fillMaxWidth()) {
                    for ((t, w) in listOf("Player" to 2f, "Pred" to 1f, "Actual" to 1f, "Round" to 1.2f, "Total" to 1.2f)) {
                        Text(t, Modifier.weight(w), color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                for (i in 0..3) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(r.names[i] + if (i == ui.mySeat) " ★" else "", Modifier.weight(2f), color = Color.White, maxLines = 1)
                        Text("${r.pred[i]}", Modifier.weight(1f), color = Color.White)
                        Text("${r.actual[i]}", Modifier.weight(1f), color = Color.White)
                        Text(signed(r.score[i]), Modifier.weight(1.2f), color = if (r.score[i] < 0) Color(0xFFFF8A80) else Color(0xFF81C784), fontWeight = FontWeight.Bold)
                        Text("${r.total[i]}", Modifier.weight(1.2f), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(12.dp))
                val bestRound = r.score.max()
                val bestTotal = r.total.max()
                Text("Round winner: " + (0..3).filter { r.score[it] == bestRound }.joinToString { r.names[it] }, color = Gold, fontWeight = FontWeight.Bold)
                Text("Overall leader: " + (0..3).filter { r.total[it] == bestTotal }.joinToString { r.names[it] }, color = Gold, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            if (ui.isHost) {
                GoldButton("Play Again", modifier = Modifier.fillMaxWidth().height(52.dp)) { vm.nextRound() }
                Spacer(Modifier.height(8.dp))
                GhostButton("Return to Lobby", Modifier.fillMaxWidth()) { vm.toLobby() }
            } else {
                Text("Waiting for the host to continue…", color = Soft)
            }
            Spacer(Modifier.height(8.dp))
            GhostButton("Leave", Modifier.fillMaxWidth()) { onLeave() }
        }
    }
}

private fun signed(v: Int) = if (v > 0) "+$v" else "$v"

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsState()
    var name by remember { mutableStateOf(s.name) }
    Felt {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back", color = Gold) }
                Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                name, { name = it.take(14); vm.updateSettings(name = name) },
                label = { Text("Your player name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Text("The name is sent when you create or join a room.", color = Soft, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Sound effects", color = Color.White, modifier = Modifier.weight(1f))
                Switch(s.sound, { vm.updateSettings(sound = it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Vibration", color = Color.White, modifier = Modifier.weight(1f))
                Switch(s.vibrate, { vm.updateSettings(vibrate = it) })
            }
        }
    }
}

@Composable
fun RulesScreen(onBack: () -> Unit) {
    Felt {
        Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back", color = Gold) }
                Text("Game Rules", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            val body = """
Setup: 4 players, one 52-card deck (no jokers), 13 cards each, 13 tricks. A trump suit is chosen at random every round. Ranking: A K Q J 10 9 8 7 6 5 4 3 2.

Prediction: before play, each player locks in how many tricks (0–13) they expect to win. The highest prediction leads the first trick; ties go to the first of those players clockwise from the dealer's left.

Playing a trick:
1. The leader may play any card.
2. Everyone else must follow the led suit if they can.
3. If you hold a higher card of the led suit than the highest led-suit card played, you must play a higher one.
4. If you can't beat it, you still must play a card of the led suit.
5. If you have no card of the led suit, you must play a trump if you have one.
6. If a trump is already down, you must overtrump it if you can.
7. If you can't overtrump, you must play a lower trump if you have one.
8. With neither led suit nor trump, play anything.
Holding the led suit means you must follow it, even if a trump has already been played.

Winning a trick: the highest trump wins; with no trump, the highest card of the led suit wins. The winner leads next.

Scoring (P = prediction, A = tricks actually won):
• A = P: +10×P
• P < A < 2P: +10×P + (A−P)
• A = 2P, A > 2P, or A < P: −10×P
• P = 0: always 0 points.
Example, P = 3: A=0,1,2 → −30; 3 → +30; 4 → +31; 5 → +32; 6 or more → −30.
""".trimIndent()
            Text(body, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
fun HistoryScreen(vm: AppViewModel, onBack: () -> Unit) {
    var rounds by remember { mutableStateOf(vm.loadHistory()) }
    val board = rounds.flatMap { r -> r.names.indices.map { i -> r.names[i] to r.score[i] } }
        .groupBy({ it.first }, { it.second })
        .map { (n, v) -> Triple(n, v.sum(), v.size) }
        .sortedByDescending { it.second }
    Felt {
        Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back", color = Gold) }
                Text("History", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Text("Leaderboard (all saved rounds on this phone)", color = Gold, fontWeight = FontWeight.Bold)
            if (board.isEmpty()) Text("No rounds played yet.", color = Soft)
            board.forEachIndexed { i, (n, pts, cnt) ->
                Text("${i + 1}. $n — ${signed(pts)} pts in $cnt round(s)", color = Color.White, modifier = Modifier.padding(vertical = 2.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("Recent rounds", color = Gold, fontWeight = FontWeight.Bold)
            for (r in rounds.asReversed().take(40)) {
                Surface(shape = RoundedCornerShape(10.dp), color = Color(0x22FFFFFF), modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("Round ${r.round}", color = Soft, fontSize = 12.sp)
                        for (i in 0..3) {
                            Text("${r.names[i]}: bid ${r.pred[i]}, won ${r.actual[i]} → ${signed(r.score[i])}", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
            if (rounds.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                GhostButton("Clear history", Modifier.fillMaxWidth()) { vm.clearHistory(); rounds = emptyList() }
            }
        }
    }
}
