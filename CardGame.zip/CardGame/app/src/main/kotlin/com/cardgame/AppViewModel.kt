package com.cardgame

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardgame.engine.Card
import com.cardgame.net.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

data class AppSettings(val name: String, val sound: Boolean, val vibrate: Boolean)
data class HostInfo(val ip: String, val port: Int, val roomId: String)

sealed class Screen {
    object Menu : Screen()
    object Join : Screen()
    object HowTo : Screen()
    object Settings : Screen()
    object History : Screen()
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("cardgame", Context.MODE_PRIVATE)

    val ui = MutableStateFlow(UiState())
    val nav = MutableStateFlow<Screen>(Screen.Menu)
    val hostInfo = MutableStateFlow<HostInfo?>(null)
    val toasts = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val settings = MutableStateFlow(
        AppSettings(prefs.getString("name", "Player") ?: "Player", prefs.getBoolean("sound", true), prefs.getBoolean("vibrate", true))
    )
    val hasLastSession = MutableStateFlow(prefs.getString("last", null) != null)

    private val nsd = NsdHelper(app)
    val rooms = nsd.rooms
    private var server: HostServer? = null
    private var client: GameClient? = null
    private var lastSavedKey = ""
    private val tone by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 50) }

    init {
        viewModelScope.launch {
            var prev = UiState()
            ui.collect { cur -> onChange(prev, cur); prev = cur }
        }
    }

    // ---------------------------------------------------------------- settings
    fun updateSettings(name: String? = null, sound: Boolean? = null, vibrate: Boolean? = null) {
        val cur = settings.value
        val n = (name ?: cur.name).take(14)
        val s = AppSettings(n, sound ?: cur.sound, vibrate ?: cur.vibrate)
        settings.value = s
        prefs.edit().putString("name", s.name).putBoolean("sound", s.sound).putBoolean("vibrate", s.vibrate).apply()
    }

    // ---------------------------------------------------------------- room creation / joining
    fun createRoom() {
        cancelJoin()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val srv = HostServer(settings.value.name) { slots -> nsd.updateSlots(slots) }
                srv.start()
                server = srv
                hostInfo.value = HostInfo(localIpv4() ?: "unknown", srv.port, srv.roomId)
                nsd.startAdvertising(srv.roomId, settings.value.name, srv.port, 3)
                connect("127.0.0.1", srv.port, srv.roomId, srv.hostToken)
            } catch (e: Exception) {
                toasts.tryEmit("Could not start the room: ${e.message}")
            }
        }
    }

    fun joinRoom(r: Room) = connect(r.ip, r.port, r.roomId, null)

    fun joinManual(ip: String, portText: String, code: String) {
        val p = portText.trim().toIntOrNull()
        if (ip.isBlank() || p == null || p !in 1..65535 || code.isBlank()) {
            toasts.tryEmit("Enter the host IP, port and room code shown in the host's lobby.")
            return
        }
        connect(ip.trim(), p, code.trim().uppercase(), null)
    }

    fun rejoinLast() {
        val s = prefs.getString("last", null) ?: return
        try {
            val j = JSONObject(s)
            connect(j.getString("ip"), j.getInt("port"), j.getString("room"), j.getString("token"))
        } catch (e: Exception) { clearLast() }
    }

    /** After HOST_LOST: try again with the same session token. */
    fun retry() {
        val c = client ?: return
        connect(c.host, c.port, c.roomId, c.token)
    }

    private fun connect(ip: String, port: Int, room: String, token: String?) {
        client?.stop()
        val c = GameClient(
            ip, port, room, settings.value.name, token,
            onUi = { ui.value = it },
            onToast = { toasts.tryEmit(it) },
            onSession = { tok, seat -> if (seat != 0) saveLast(ip, port, room, tok) },
            onEnded = { clearLast() }
        )
        client = c
        ui.value = UiState(conn = ConnState.CONNECTING)
        c.start()
    }

    fun cancelJoin() {
        if (server != null) return
        client?.stop(); client = null
        ui.value = UiState()
    }

    fun leave() {
        val c = client
        val s = server
        client = null; server = null
        hostInfo.value = null
        c?.leave()
        clearLast()
        ui.value = UiState()
        nav.value = Screen.Menu
        viewModelScope.launch(Dispatchers.IO) { s?.stop(); nsd.stopAdvertising() }
    }

    fun startDiscovery() = nsd.startDiscovery()
    fun stopDiscovery() = nsd.stopDiscovery()
    fun toast(msg: String) { toasts.tryEmit(msg) }

    // ---------------------------------------------------------------- in-game actions (all validated by the host)
    private fun send(j: JSONObject) { client?.send(j) }
    fun predict(v: Int) = send(JSONObject().put("t", "predict").put("v", v))
    fun play(c: Card) = send(JSONObject().put("t", "play").put("c", c.code()))
    fun startGame() = send(JSONObject().put("t", "start"))
    fun nextRound() = send(JSONObject().put("t", "next"))
    fun toLobby() = send(JSONObject().put("t", "lobby"))
    fun abortRound() = send(JSONObject().put("t", "abort"))

    // ---------------------------------------------------------------- persistence
    private fun saveLast(ip: String, port: Int, room: String, token: String) {
        prefs.edit().putString("last", JSONObject().put("ip", ip).put("port", port).put("room", room).put("token", token).toString()).apply()
        hasLastSession.value = true
    }

    private fun clearLast() {
        prefs.edit().remove("last").apply()
        hasLastSession.value = false
    }

    fun loadHistory(): List<RoundResult> = try {
        val a = JSONArray(prefs.getString("history", "[]"))
        List(a.length()) { RoundResult.fromJson(a.getJSONObject(it)) }
    } catch (e: Exception) { emptyList() }

    fun clearHistory() { prefs.edit().remove("history").apply() }

    private fun saveHistory(cur: UiState) {
        val r = cur.history.lastOrNull() ?: return
        val key = "${cur.roomId}:${r.ts}"
        if (key == lastSavedKey) return
        lastSavedKey = key
        val all = loadHistory().toMutableList()
        if (all.any { it.ts == r.ts && it.round == r.round }) return
        all.add(r)
        val trimmed = all.takeLast(300)
        prefs.edit().putString("history", JSONArray(trimmed.map { it.toJson() }).toString()).apply()
    }

    // ---------------------------------------------------------------- sound / vibration cues
    private fun onChange(prev: UiState, cur: UiState) {
        if (cur.phase == Phase.PLAY && cur.trick.size > prev.trick.size) cue(false)
        if (cur.phase == Phase.PLAY && cur.turn == cur.mySeat && prev.turn != cur.mySeat) vibrate(35)
        if (cur.phase == Phase.ROUND_END && prev.phase != Phase.ROUND_END) cue(true)
        if (cur.phase == Phase.ROUND_END) saveHistory(cur)
    }

    private fun cue(big: Boolean) {
        if (settings.value.sound) {
            try { tone.startTone(if (big) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, 120) } catch (_: Exception) {}
        }
        vibrate(if (big) 120 else 25)
    }

    private fun vibrate(ms: Long) {
        if (!settings.value.vibrate) return
        try {
            getApplication<Application>().getSystemService(Vibrator::class.java)
                ?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        client?.stop()
        val s = server
        Thread { s?.stop() }.start()
        nsd.stopAdvertising(); nsd.stopDiscovery()
        try { tone.release() } catch (_: Exception) {}
    }
}
