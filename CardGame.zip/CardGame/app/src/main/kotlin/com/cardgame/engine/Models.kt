package com.cardgame.engine

import java.security.SecureRandom
import kotlin.random.asKotlinRandom

enum class Suit(val symbol: String) { HEARTS("♥"), DIAMONDS("♦"), CLUBS("♣"), SPADES("♠") }

/** value: 2..14 where 11=J, 12=Q, 13=K, 14=A. Higher always beats lower. */
data class Card(val suit: Suit, val value: Int) {
    init { require(value in 2..14) { "Invalid rank $value" } }
    val label: String get() = when (value) { 11 -> "J"; 12 -> "Q"; 13 -> "K"; 14 -> "A"; else -> "$value" } + suit.symbol
}

/** A card played by a seat (0..3) in the current trick. */
data class Play(val seat: Int, val card: Card)

object Deck {
    fun standard52(): List<Card> = Suit.values().flatMap { s -> (2..14).map { Card(s, it) } }

    /** Fisher–Yates with a cryptographically secure RNG (host-side only). */
    fun shuffled(rng: kotlin.random.Random = SecureRandom().asKotlinRandom()): List<Card> =
        standard52().toMutableList().also { it.shuffle(rng) }

    /** Returns 4 hands of 13 cards, dealt one at a time starting at the dealer's left. */
    fun deal(deck: List<Card>, dealer: Int): List<List<Card>> {
        require(deck.size == 52 && deck.toSet().size == 52) { "Deck must be 52 unique cards" }
        val hands = List(4) { mutableListOf<Card>() }
        deck.forEachIndexed { i, c -> hands[(dealer + 1 + i) % 4].add(c) }
        return hands
    }

    fun randomTrump(rng: kotlin.random.Random = SecureRandom().asKotlinRandom()): Suit = Suit.values().random(rng)

    /** Sort by suit then rank (high to low). */
    fun sorted(hand: List<Card>): List<Card> = hand.sortedWith(compareBy<Card> { it.suit.ordinal }.thenByDescending { it.value })
}
