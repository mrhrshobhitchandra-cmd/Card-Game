package com.cardgame.net

import java.net.Inet4Address
import java.net.NetworkInterface

/** Best-guess local Wi-Fi / hotspot IPv4 address of this phone. */
fun localIpv4(): String? {
    val all = NetworkInterface.getNetworkInterfaces() ?: return null
    val cands = mutableListOf<Pair<String, String>>()
    for (ni in all.toList()) {
        if (!ni.isUp || ni.isLoopback) continue
        for (a in ni.inetAddresses.toList()) {
            if (a is Inet4Address && a.isSiteLocalAddress) cands.add(ni.name to (a.hostAddress ?: continue))
        }
    }
    return (cands.firstOrNull { it.first.startsWith("wlan") } ?: cands.firstOrNull())?.second
}
