package com.cardgame.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardgame.AppViewModel
import com.cardgame.engine.Card
import com.cardgame.engine.Deck
import com.cardgame.engine.MoveResult
import com.cardgame.engine.Rules
import com.cardgame.engine.Suit
import com.cardgame.net.Phase
import com.cardgame.net.UiState

fun rankLabel(v: Int): String = when (v) { 11 -> "J"; 12 -> "Q"; 13 -> "K"; 14 -> "A"; else -> "$v" }
fun suitColor(s: Suit): Color = if (s == Suit.HEARTS || s == Suit.DIAMONDS) Color(0xFFC62828) else Color(0xFF1B1B1B)

@Composable
fun CardFace(card: Card, width: Dp, modifier: Modifier = Modifier, dim: Boolean = false, highlight: Boolean = false) {
    val shape = RoundedCornerShape(6.dp)
    val color = suitColor(card.suit)
    Box(
        modifier
            .width(width).height(width * 1.4f)
            .shadow(3.dp, shape)
            .clip(shape)
            .background(if (dim) Color(0xFFB0B0B0) else Color.White)
            .border(if (highlight) 3.dp else 1.dp, if (highlight) Gold else Color(0xFF9E9E9E), shape)
    ) {
        Column(Modifier.padding(start = 4.dp, top = 2.dp)) {
            Text(rankLabel(card.value), color = color, fontWeight = FontWeight.Bold, fontSize = (width.value * 0.30f).sp, lineHeight = (width.value * 0.32f).sp)
            Text(card.suit.symbol, color = color, fontSize = (width.value * 0.26f).sp, lineHeight = (width.value * 0.26f).sp)
        }
        Text(card.suit.symbol, color = color, fontSize = (width.value * 0.55f).sp, modifier = Modifier.align(Alignment.Center))
    }
}

@Composable
fun PlayerPanel(ui: UiState, seat: Int, modifier: Modifier = Modifier) {
    val isTurn = ui.turn == seat
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0x66000000),
        border = if (isTurn) BorderStroke(2.dp, Gold) else null,
        modifier = modifier
    ) {
        Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (ui.connected[seat]) Color(0xFF4CAF50) else Color(0xFFF44336)))
                Spacer(Modifier.width(4.dp))
                Text(ui.names[seat], color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("Bid ${if (ui.pred[seat] >= 0) ui.pred[seat].toString() else "–"} · Won ${ui.tricks[seat]}", color = Color(0xCCFFFFFF), fontSize = 11.sp)
            Text("Score ${ui.total[seat]}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("${ui.counts[seat]} cards", color = Color(0x99FFFFFF), fontSize = 10.sp)
        }
    }
}

@Composable
fun TrickArea(ui: UiState, me: Int, modifier: Modifier) {
    Box(modifier) {
        for (p in ui.trick) {
            key(p.seat, p.card) {
                val rel = (p.seat - me + 4) % 4
                val align = when (rel) {
                    0 -> Alignment.BottomCenter
                    1 -> Alignment.CenterStart
                    2 -> Alignment.TopCenter
                    else -> Alignment.CenterEnd
                }
                val state = remember { MutableTransitionState(false).apply { targetState = true } }
                AnimatedVisibility(visibleState = state, enter = scaleIn() + fadeIn(), modifier = Modifier.align(align).padding(4.dp)) {
                    CardFace(p.card, 44.dp, highlight = ui.trickWinner == p.seat)
                }
            }
        }
    }
}

@Composable
fun HandRow(hand: List<Card>, legal: Set<Card>, dimIllegal: Boolean, selected: Card?, onTap: (Card) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth().height(112.dp)) {
        val cardW = 60.dp
        val n = hand.size
        val fit = if (n > 1) (maxWidth - cardW) / (n - 1) else 0.dp
        val ideal = cardW * 0.75f
        val step = if (fit < ideal) fit else ideal
        val totalW = cardW + step * (if (n > 0) n - 1 else 0)
        val startX = (maxWidth - totalW) / 2
        hand.forEachIndexed { i, c ->
            key(c) {
                val raised by animateDpAsState(if (c == selected) (-18).dp else 0.dp, label = "raise")
                Box(Modifier.offset(x = startX + step * i, y = 20.dp + raised).clickable { onTap(c) }) {
                    CardFace(c, cardW, dim = dimIllegal && c !in legal, highlight = c == selected)
                }
            }
        }
    }
}

@Composable
fun TableScreen(vm: AppViewModel, ui: UiState, onLeave: () -> Unit) {
    val me = ui.mySeat
    val trump = ui.trump
    var selected by remember { mutableStateOf<Card?>(null) }
    var bySuit by remember { mutableStateOf(true) }
    var bid by remember { mutableStateOf<Int?>(null) }
    val myTurn = ui.phase == Phase.PLAY && ui.turn == me && !ui.paused && trump != null
    val legal: Set<Card> = remember(ui.hand, ui.trick, trump, myTurn) {
        if (myTurn && trump != null) Rules.legalCards(ui.hand, ui.trick, trump).toSet() else ui.hand.toSet()
    }
    val hand = remember(ui.hand, bySuit) {
        if (bySuit) Deck.sorted(ui.hand)
        else ui.hand.sortedWith(compareByDescending<Card> { it.value }.thenBy { it.suit.ordinal })
    }
    LaunchedEffect(ui.hand) { selected = null }
    LaunchedEffect(ui.round) { bid = null }

    fun playCard(c: Card) {
        if (trump != null) {
            val r = Rules.validate(ui.hand, c, ui.trick, trump)
            if (r is MoveResult.Illegal) { vm.toast(r.reason); return }
        }
        vm.play(c)
        selected = null
    }

    val status = when {
        ui.paused -> "Paused – waiting for " + (0..3).filter { !ui.connected[it] }.joinToString { ui.names[it] } + " to reconnect"
        ui.phase == Phase.PREDICT -> "Prediction phase – ${ui.pred.count { it >= 0 }}/4 locked"
        ui.trickWinner >= 0 -> "${ui.names[ui.trickWinner]} wins the trick"
        myTurn -> "Your turn"
        ui.turn >= 0 -> "${ui.names[ui.turn]}'s turn"
        else -> ""
    }

    Felt {
        Column(Modifier.fillMaxSize().padding(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Trump", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                Spacer(Modifier.width(6.dp))
                if (trump != null) {
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color.White).padding(horizontal = 8.dp)) {
                        Text(trump.symbol, color = suitColor(trump), fontSize = 26.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("Round ${ui.round}", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onLeave) { Text("Leave", color = Color(0xFFFF8A80)) }
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PlayerPanel(ui, (me + 2) % 4, Modifier.width(150.dp))
            }
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Box(Modifier.width(92.dp).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    PlayerPanel(ui, (me + 1) % 4, Modifier.fillMaxWidth())
                }
                TrickArea(ui, me, Modifier.weight(1f).fillMaxHeight())
                Box(Modifier.width(92.dp).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    PlayerPanel(ui, (me + 3) % 4, Modifier.fillMaxWidth())
                }
            }
            Text(
                status, color = if (myTurn) Gold else Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            if (ui.paused && ui.isHost) {
                OutlinedButton(onClick = { vm.abortRound() }, modifier = Modifier.fillMaxWidth()) {
                    Text("End this round and return to lobby", color = Color(0xFFFF8A80))
                }
            }
            if (ui.phase == Phase.PREDICT && ui.pred[me] < 0) {
                Text("How many tricks will you win?", color = Color.White, fontSize = 13.sp)
                for (start in listOf(0, 7)) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (n in start until start + 7) {
                            val sel = bid == n
                            Button(
                                onClick = { bid = n },
                                modifier = Modifier.weight(1f).height(38.dp),
                                contentPadding = PaddingValues(0.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (sel) Gold else Color(0x55FFFFFF),
                                    contentColor = if (sel) Color.Black else Color.White
                                )
                            ) { Text("$n", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                GoldButton("Lock in: ${bid ?: "-"}", enabled = bid != null, modifier = Modifier.fillMaxWidth()) { bid?.let { vm.predict(it) } }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (myTurn) Gold else Color.Transparent))
                Spacer(Modifier.width(6.dp))
                Text(
                    "You · Bid ${if (ui.pred[me] >= 0) ui.pred[me].toString() else "–"} · Won ${ui.tricks[me]} · Score ${ui.total[me]}",
                    color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { bySuit = !bySuit }) { Text(if (bySuit) "Sort: suit" else "Sort: rank", color = Gold, fontSize = 12.sp) }
                if (myTurn && selected != null) {
                    GoldButton("Play") { selected?.let { playCard(it) } }
                }
            }
            HandRow(hand, legal, dimIllegal = myTurn, selected = selected) { c ->
                if (myTurn && c !in legal) {
                    if (trump != null) {
                        val r = Rules.validate(ui.hand, c, ui.trick, trump)
                        if (r is MoveResult.Illegal) vm.toast(r.reason)
                    }
                } else if (myTurn && selected == c) {
                    playCard(c)
                } else {
                    selected = c
                }
            }
        }
    }
}
