package com.cardgame.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Room(val key: String, val ip: String, val port: Int, val roomId: String, val hostName: String, val slots: Int)

/** mDNS / NSD advertising (host) and discovery (clients). */
class NsdHelper(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val serviceType = "_trumpcards._tcp."

    private val _rooms = MutableStateFlow<List<Room>>(emptyList())
    val rooms: StateFlow<List<Room>> = _rooms
    private val found = LinkedHashMap<String, Room>()
    private val queue = mutableListOf<NsdServiceInfo>()
    private var resolving = false
    private var discovery: NsdManager.DiscoveryListener? = null
    private var mcLock: WifiManager.MulticastLock? = null

    private var reg: NsdManager.RegistrationListener? = null
    private var regRoom = ""
    private var regHost = ""
    private var regPort = 0
    private var regSlots = 3
    private var reRegister = false

    // ---------- advertising ----------
    @Synchronized
    fun startAdvertising(roomId: String, hostName: String, port: Int, slots: Int) {
        stopAdvertising()
        regRoom = roomId; regHost = hostName; regPort = port; regSlots = slots
        register()
    }

    private fun register() {
        val info = NsdServiceInfo().apply {
            serviceName = "TC-$regRoom"
            serviceType = this@NsdHelper.serviceType
            port = regPort
            setAttribute("room", regRoom)
            setAttribute("host", regHost)
            setAttribute("slots", regSlots.toString())
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(si: NsdServiceInfo) {}
            override fun onRegistrationFailed(si: NsdServiceInfo, code: Int) {}
            override fun onServiceUnregistered(si: NsdServiceInfo) {
                synchronized(this@NsdHelper) {
                    if (reRegister) { reRegister = false; register() }
                }
            }
            override fun onUnregistrationFailed(si: NsdServiceInfo, code: Int) {}
        }
        reg = l
        try { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) { reg = null }
    }

    /** Re-advertise with a new free-slot count (unregister, then register again). */
    @Synchronized
    fun updateSlots(slots: Int) {
        if (slots == regSlots) return
        regSlots = slots
        val l = reg ?: return
        reRegister = true
        try { nsd.unregisterService(l) } catch (_: Exception) { reRegister = false }
    }

    @Synchronized
    fun stopAdvertising() {
        reRegister = false
        reg?.let { try { nsd.unregisterService(it) } catch (_: Exception) {} }
        reg = null
    }

    // ---------- discovery ----------
    @Synchronized
    fun startDiscovery() {
        stopDiscovery()
        try {
            mcLock = wifi.createMulticastLock("cardgame").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onServiceFound(si: NsdServiceInfo) {
                if (si.serviceType.contains("_trumpcards")) enqueue(si)
            }
            override fun onServiceLost(si: NsdServiceInfo) {
                synchronized(this@NsdHelper) { found.remove(si.serviceName); publish() }
            }
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        discovery = l
        try { nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) { discovery = null }
    }

    @Synchronized
    fun stopDiscovery() {
        discovery?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        discovery = null
        try { mcLock?.release() } catch (_: Exception) {}
        mcLock = null
        queue.clear(); resolving = false; found.clear(); publish()
    }

    @Synchronized
    private fun enqueue(si: NsdServiceInfo) { queue.add(si); pump() }

    @Synchronized
    private fun pump() {
        if (resolving) return
        val si = queue.removeFirstOrNull() ?: return
        resolving = true
        try {
            nsd.resolveService(si, object : NsdManager.ResolveListener {
                override fun onResolveFailed(s: NsdServiceInfo, code: Int) { done() }
                override fun onServiceResolved(s: NsdServiceInfo) {
                    val attrs = s.attributes
                    fun a(k: String): String = attrs[k]?.toString(Charsets.UTF_8) ?: ""
                    val ip = s.host?.hostAddress
                    if (ip != null && a("room").isNotEmpty()) {
                        synchronized(this@NsdHelper) {
                            found[s.serviceName] = Room(s.serviceName, ip, s.port, a("room"), a("host"), a("slots").toIntOrNull() ?: 0)
                            publish()
                        }
                    }
                    done()
                }
            })
        } catch (e: Exception) { resolving = false }
    }

    private fun done() { synchronized(this) { resolving = false; pump() } }
    private fun publish() { _rooms.value = found.values.toList() }
}
