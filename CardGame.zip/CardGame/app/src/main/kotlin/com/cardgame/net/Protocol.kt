package com.cardgame.net

import com.cardgame.engine.Card
import com.cardgame.engine.Play
import com.cardgame.engine.Suit
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.Socket

enum class Phase { LOBBY, PREDICT, PLAY, ROUND_END }
enum class ConnState { IDLE, CONNECTING, ONLINE, RECONNECTING, HOST_LOST, REJECTED }

fun Card.code(): String = "${suit.name[0]}$value"
fun suitOf(ch: Char): Suit? = Suit.values().firstOrNull { it.name[0] == ch }
fun parseCard(s: String): Card? {
    if (s.length < 2) return null
    val suit = suitOf(s[0]) ?: return null
    val v = s.substring(1).toIntOrNull() ?: return null
    if (v !in 2..14) return null
    return Card(suit, v)
}

fun parseJson(line: String): JSONObject? = try { JSONObject(line) } catch (e: Exception) { null }
fun JSONArray.ints(): List<Int> = List(length()) { getInt(it) }
fun JSONArray.strs(): List<String> = List(length()) { getString(it) }
fun JSONArray.bools(): List<Boolean> = List(length()) { getBoolean(it) }

/** One newline-terminated JSON object per message. */
class Conn(val socket: Socket) {
    private val out = socket.getOutputStream()

    @Synchronized
    fun send(j: JSONObject) {
        try {
            out.write((j.toString() + "\n").toByteArray(Charsets.UTF_8))
            out.flush()
        } catch (e: IOException) {
            close()
        }
    }

    fun close() { try { socket.close() } catch (_: Exception) {} }
}

data class RoundResult(
    val ts: Long, val round: Int, val names: List<String>,
    val pred: List<Int>, val actual: List<Int>, val score: List<Int>, val total: List<Int>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("ts", ts).put("round", round)
        .put("names", JSONArray(names)).put("pred", JSONArray(pred))
        .put("actual", JSONArray(actual)).put("score", JSONArray(score)).put("total", JSONArray(total))

    companion object {
        fun fromJson(j: JSONObject) = RoundResult(
            j.optLong("ts"), j.getInt("round"), j.getJSONArray("names").strs(),
            j.getJSONArray("pred").ints(), j.getJSONArray("actual").ints(),
            j.getJSONArray("score").ints(), j.getJSONArray("total").ints()
        )
    }
}

/** Everything the UI needs. Contains ONLY this player's own hand plus public information. */
data class UiState(
    val conn: ConnState = ConnState.IDLE,
    val notice: String = "",
    val roomId: String = "",
    val mySeat: Int = -1,
    val phase: Phase? = null,
    val round: Int = 0,
    val dealer: Int = 0,
    val trump: Suit? = null,
    val turn: Int = -1,
    val names: List<String> = List(4) { "" },
    val seated: List<Boolean> = List(4) { false },
    val connected: List<Boolean> = List(4) { false },
    val pred: List<Int> = List(4) { -1 },
    val tricks: List<Int> = List(4) { 0 },
    val total: List<Int> = List(4) { 0 },
    val roundScore: List<Int> = List(4) { 0 },
    val counts: List<Int> = List(4) { 0 },
    val trick: List<Play> = emptyList(),
    val trickWinner: Int = -1,
    val paused: Boolean = false,
    val hand: List<Card> = emptyList(),
    val history: List<RoundResult> = emptyList(),
    val version: Int = -1
) {
    val isHost: Boolean get() = mySeat == 0
}
