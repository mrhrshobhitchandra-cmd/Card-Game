package com.cardgame.engine

object Scoring {
    /** The single authoritative scoring function. P = predicted, A = actual tricks. */
    fun roundScore(p: Int, a: Int): Int {
        require(p in 0..13 && a in 0..13)
        return when {
            p == 0 -> 0
            a == p -> 10 * p
            a > p && a < 2 * p -> 10 * p + (a - p)
            else -> -10 * p            // A < P, A == 2P, A > 2P
        }
    }
}
