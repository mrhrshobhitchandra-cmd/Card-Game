package com.cardgame.net

import com.cardgame.engine.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.random.asKotlinRandom

/**
 * Host-authoritative game server. It owns the only official game state, validates every move,
 * and sends each connected seat ONLY that seat's own hand plus public information.
 * The host player's own phone talks to this server through a normal loopback connection,
 * so the host UI never receives anyone else's cards.
 */
class HostServer(hostName: String, private val onSlots: (Int) -> Unit) {

    private class Seat(var name: String, val token: String) {
        @Volatile var conn: Conn? = null
    }

    private val secure = SecureRandom()
    private val rng = secure.asKotlinRandom()
    val roomId: String = (1..4).map { "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".random(rng) }.joinToString("")
    val hostToken: String = newToken()
    var port: Int = 0
        private set

    private val lock = Any()
    private var server: ServerSocket? = null
    @Volatile private var running = false
    private val scheduler = Executors.newSingleThreadScheduledExecutor()

    private val seats = arrayOfNulls<Seat>(4)
    private var phase = Phase.LOBBY
    private var version = 0
    private var round = 0
    private var dealer = rng.nextInt(4)
    private var trump: Suit? = null
    private val hands = Array(4) { mutableListOf<Card>() }
    private val pred = IntArray(4) { -1 }
    private val tricks = IntArray(4)
    private val total = IntArray(4)
    private val roundScore = IntArray(4)
    private var turn = -1
    private val trick = mutableListOf<Play>()
    private var trickWinner = -1
    private var resolving = false
    private val history = mutableListOf<RoundResult>()

    init { seats[0] = Seat(sanitize(hostName), hostToken) }

    private fun newToken(): String {
        val b = ByteArray(16); secure.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    private fun sanitize(n: String): String = n.trim().replace(Regex("[\\p{Cntrl}]"), "").take(14).ifEmpty { "Player" }

    // ------------------------------------------------------------------ lifecycle
    fun start() {
        val s = ServerSocket(0)
        server = s
        port = s.localPort
        running = true
        Thread({ acceptLoop(s) }, "host-accept").apply { isDaemon = true }.start()
        scheduler.scheduleAtFixedRate(Runnable { pingAll() }, 3, 3, TimeUnit.SECONDS)
    }

    fun stop() {
        synchronized(lock) {
            if (!running) return
            running = false
            val bye = JSONObject().put("t", "closed")
            for (s in seats) s?.conn?.send(bye)
        }
        try { server?.close() } catch (_: Exception) {}
        for (s in seats) s?.conn?.close()
        scheduler.shutdownNow()
    }

    private fun pingAll() {
        val p = JSONObject().put("t", "ping")
        for (s in seats) s?.conn?.send(p)
    }

    private fun acceptLoop(s: ServerSocket) {
        while (running) {
            val sock = try { s.accept() } catch (e: IOException) { break }
            Thread({ handleClient(sock) }, "host-client").apply { isDaemon = true }.start()
        }
    }

    // ------------------------------------------------------------------ connections
    private fun handleClient(socket: Socket) {
        val conn = Conn(socket)
        var seat = -1
        try {
            socket.soTimeout = 12000
            socket.tcpNoDelay = true
            socket.keepAlive = true
            val reader = socket.getInputStream().bufferedReader(Charsets.UTF_8)
            val first = reader.readLine() ?: return
            val hello = parseJson(first) ?: return
            if (hello.optString("t") != "hello" || hello.optString("room") != roomId) {
                conn.send(reject("Wrong room code."))
                return
            }
            seat = admit(conn, hello)
            if (seat < 0) return
            while (running) {
                val line = reader.readLine() ?: break
                if (line.length > 4096) continue
                val j = parseJson(line) ?: continue
                dispatch(seat, j)
            }
        } catch (e: Exception) {
            // connection error: handled in finally
        } finally {
            if (seat >= 0) onDisconnect(seat, conn) else conn.close()
        }
    }

    private fun reject(msg: String) = JSONObject().put("t", "reject").put("msg", msg)

    private fun admit(conn: Conn, hello: JSONObject): Int = synchronized(lock) { admitLocked(conn, hello) }

    private fun admitLocked(conn: Conn, hello: JSONObject): Int {
        val token = hello.optString("token", "")
            if (token.isNotEmpty()) {
                val i = seats.indexOfFirst { it?.token == token }
                if (i < 0) {
                    conn.send(reject("Session not recognised. The game may have been restarted."))
                    return -1
                }
                val s = seats[i]!!
                val old = s.conn
                s.conn = conn
                if (old != null && old !== conn) old.close()
                conn.send(JSONObject().put("t", "welcome").put("seat", i).put("token", s.token).put("room", roomId))
                bump(); broadcast(); notifySlots()
                return i
            }
            if (phase != Phase.LOBBY) {
                conn.send(reject("A game is already in progress."))
                return -1
            }
            var i = seats.indexOfFirst { it == null }
            if (i < 0) i = (1..3).firstOrNull { seats[it]?.conn == null } ?: -1
            if (i < 0) {
                conn.send(reject("Room is full."))
                return -1
            }
            val s = Seat(uniqueName(sanitize(hello.optString("name", "Player")), i), newToken())
            s.conn = conn
            seats[i] = s
            conn.send(JSONObject().put("t", "welcome").put("seat", i).put("token", s.token).put("room", roomId))
            bump(); broadcast(); notifySlots()
            return i
    }

    private fun uniqueName(base: String, seat: Int): String {
        var n = base; var k = 2
        while ((0..3).any { it != seat && seats[it]?.name.equals(n, ignoreCase = true) }) { n = "$base $k"; k++ }
        return n
    }

    private fun onDisconnect(seat: Int, conn: Conn) {
        synchronized(lock) {
            val s = seats[seat]
            if (s != null && s.conn === conn) {
                s.conn = null
                bump(); broadcast(); notifySlots()
            }
        }
        conn.close()
    }

    // ------------------------------------------------------------------ message handling
    private fun dispatch(seat: Int, j: JSONObject) {
        synchronized(lock) { handle(seat, j) }
    }

    private fun handle(seat: Int, j: JSONObject) {
        when (j.optString("t")) {
            "predict" -> onPredict(seat, j.optInt("v", -1))
            "play" -> onPlay(seat, j.optString("c", ""))
            "start" -> {
                if (seat == 0 && phase == Phase.LOBBY) {
                    if (allConnected()) startRound() else err(seat, "All four players must be connected.")
                }
            }
            "next" -> {
                if (seat == 0 && phase == Phase.ROUND_END) {
                    if (allConnected()) startRound() else err(seat, "Waiting for all players to reconnect.")
                }
            }
            "lobby" -> {
                if (seat == 0 && phase == Phase.ROUND_END) {
                    total.fill(0); round = 0
                    resetToLobby()
                }
            }
            "abort" -> {
                if (seat == 0 && (phase == Phase.PREDICT || phase == Phase.PLAY)) resetToLobby()
            }
            "leave" -> onLeave(seat)
            else -> {}
        }
    }

    private fun allConnected() = (0..3).all { seats[it]?.conn != null }
    private fun isPaused() = (phase == Phase.PREDICT || phase == Phase.PLAY) && !allConnected()
    private fun freeSlots() = if (phase != Phase.LOBBY) 0 else (1..3).count { seats[it]?.conn == null }
    private fun notifySlots() { onSlots(freeSlots()) }
    private fun bump() { version++ }
    private fun err(seat: Int, msg: String) { seats[seat]?.conn?.send(JSONObject().put("t", "error").put("msg", msg)) }

    private fun onLeave(seat: Int) {
        if (seat == 0) { stop(); return }
        val s = seats[seat] ?: return
        val c = s.conn
        s.conn = null
        c?.close()
        if (phase == Phase.LOBBY) seats[seat] = null
        bump(); broadcast(); notifySlots()
    }

    private fun onPredict(seat: Int, v: Int) {
        if (phase != Phase.PREDICT) { err(seat, "Predictions are closed."); return }
        if (pred[seat] != -1) { err(seat, "Your prediction is already locked."); return }
        if (v !in 0..13) { err(seat, "Prediction must be between 0 and 13."); return }
        pred[seat] = v
        if (pred.all { it >= 0 }) {
            phase = Phase.PLAY
            turn = Rules.firstLeader(pred.toList(), dealer)
        }
        bump(); broadcast()
    }

    private fun onPlay(seat: Int, code: String) {
        val tr = trump
        if (phase != Phase.PLAY || tr == null) { err(seat, "Not in the playing phase."); return }
        if (isPaused()) { err(seat, "Game is paused: a player is disconnected."); return }
        if (resolving) { err(seat, "Wait for the trick to finish."); return }
        if (turn != seat) { err(seat, "It is not your turn."); return }
        val card = parseCard(code)
        if (card == null) { err(seat, "Invalid card."); return }
        when (val r = Rules.validate(hands[seat], card, trick.toList(), tr)) {
            is MoveResult.Illegal -> { err(seat, r.reason); return }
            MoveResult.Legal -> {}
        }
        hands[seat].remove(card)
        trick.add(Play(seat, card))
        if (trick.size < 4) {
            turn = (seat + 1) % 4
        } else {
            resolving = true
            turn = -1
            trickWinner = Rules.trickWinner(trick.toList(), tr)
            scheduler.schedule(Runnable { synchronized(lock) { resolveTrick() } }, 1600, TimeUnit.MILLISECONDS)
        }
        bump(); broadcast()
    }

    private fun resolveTrick() {
        if (!resolving || phase != Phase.PLAY) return
        val w = trickWinner
        tricks[w]++
        trick.clear()
        trickWinner = -1
        resolving = false
        if (hands.all { it.isEmpty() }) endRound() else turn = w
        bump(); broadcast()
    }

    private fun startRound() {
        round++
        dealer = (dealer + 1) % 4
        val deal = Deck.deal(Deck.shuffled(rng), dealer)
        for (i in 0..3) { hands[i].clear(); hands[i].addAll(deal[i]) }
        trump = Deck.randomTrump(rng)
        pred.fill(-1); tricks.fill(0); roundScore.fill(0)
        trick.clear(); trickWinner = -1; resolving = false; turn = -1
        phase = Phase.PREDICT
        bump(); broadcast(); notifySlots()
    }

    private fun endRound() {
        for (i in 0..3) {
            roundScore[i] = Scoring.roundScore(pred[i], tricks[i])
            total[i] += roundScore[i]
        }
        history.add(
            RoundResult(
                System.currentTimeMillis(), round, List(4) { seats[it]?.name ?: "" },
                pred.toList(), tricks.toList(), roundScore.toList(), total.toList()
            )
        )
        phase = Phase.ROUND_END
        turn = -1
    }

    private fun resetToLobby() {
        phase = Phase.LOBBY
        for (h in hands) h.clear()
        trick.clear(); trickWinner = -1; resolving = false; turn = -1; trump = null
        pred.fill(-1); tricks.fill(0); roundScore.fill(0)
        bump(); broadcast(); notifySlots()
    }

    // ------------------------------------------------------------------ state distribution
    private fun broadcast() {
        for (i in 0..3) seats[i]?.conn?.send(stateFor(i))
    }

    /** Public information plus ONLY seat i's own hand. */
    private fun stateFor(i: Int): JSONObject {
        val inRound = phase == Phase.PREDICT || phase == Phase.PLAY
        return JSONObject()
            .put("t", "state").put("v", version)
            .put("phase", phase.name).put("round", round).put("dealer", dealer)
            .put("trump", trump?.name?.substring(0, 1) ?: "")
            .put("turn", turn)
            .put("names", JSONArray(List(4) { seats[it]?.name ?: "" }))
            .put("seated", JSONArray(List(4) { seats[it] != null }))
            .put("conn", JSONArray(List(4) { seats[it]?.conn != null }))
            .put("pred", JSONArray(pred.toList()))
            .put("tricks", JSONArray(tricks.toList()))
            .put("total", JSONArray(total.toList()))
            .put("rscore", JSONArray(roundScore.toList()))
            .put("counts", JSONArray(List(4) { hands[it].size }))
            .put("trick", JSONArray(trick.map { JSONObject().put("s", it.seat).put("c", it.card.code()) }))
            .put("tw", trickWinner)
            .put("paused", isPaused())
            .put("hand", JSONArray(if (inRound) hands[i].map { it.code() } else emptyList<String>()))
            .put("hist", JSONArray(history.takeLast(20).map { it.toJson() }))
    }
}
