package com.cardgame.engine

sealed class MoveResult {
    object Legal : MoveResult()
    data class Illegal(val reason: String) : MoveResult()
}

object Rules {

    /** All cards in [hand] that may legally be played given the cards already in [trick]. */
    fun legalCards(hand: List<Card>, trick: List<Play>, trump: Suit): List<Card> {
        if (trick.isEmpty()) return hand                                   // Rule 1
        val led = trick.first().card.suit
        val ledCards = hand.filter { it.suit == led }

        if (ledCards.isNotEmpty()) {                                       // Rules 2-4 (must follow suit, even if trump already played)
            val highestLed = trick.map { it.card }.filter { it.suit == led }.maxOf { it.value }
            val higher = ledCards.filter { it.value > highestLed }
            return if (higher.isNotEmpty()) higher else ledCards
        }

        val trumps = hand.filter { it.suit == trump }
        if (trumps.isNotEmpty()) {                                         // Rules 5-7
            val trumpsPlayed = trick.map { it.card }.filter { it.suit == trump }
            if (trumpsPlayed.isEmpty()) return trumps
            val top = trumpsPlayed.maxOf { it.value }
            val over = trumps.filter { it.value > top }
            return if (over.isNotEmpty()) over else trumps                 // cannot overtrump -> any (lower) trump
        }
        return hand                                                        // Rule 8
    }

    fun validate(hand: List<Card>, card: Card, trick: List<Play>, trump: Suit): MoveResult {
        if (card !in hand) return MoveResult.Illegal("You don't hold that card.")
        if (card in legalCards(hand, trick, trump)) return MoveResult.Legal
        val led = trick.first().card.suit
        val hasLed = hand.any { it.suit == led }
        val reason = when {
            hasLed && card.suit != led -> "You must follow the led suit ${led.symbol}."
            hasLed -> "You hold a higher ${led.symbol} than the highest played, so you must play a higher one."
            hand.any { it.suit == trump } && card.suit != trump -> "You have no ${led.symbol}, so you must play a trump ${trump.symbol}."
            else -> "You must overtrump the current highest trump if you can."
        }
        return MoveResult.Illegal(reason)
    }

    /** Highest trump wins if any trump was played; otherwise highest card of the led suit. Returns winning seat. */
    fun trickWinner(trick: List<Play>, trump: Suit): Int {
        require(trick.size == 4) { "Trick must have 4 cards" }
        val trumps = trick.filter { it.card.suit == trump }
        val pool = if (trumps.isNotEmpty()) trumps else trick.filter { it.card.suit == trick.first().card.suit }
        return pool.maxByOrNull { it.card.value }!!.seat
    }

    /** Highest prediction leads; ties broken by seating order starting from the dealer's left. */
    fun firstLeader(predictions: List<Int>, dealer: Int): Int {
        require(predictions.size == 4 && predictions.all { it in 0..13 })
        val max = predictions.max()
        return (1..4).map { (dealer + it) % 4 }.first { predictions[it] == max }
    }
}
