package com.cardgame.net

import com.cardgame.engine.Play
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Client connection used by EVERY player (the host's own phone connects over loopback).
 * Handles framing, heartbeat, automatic reconnection with the session token, and
 * ignores out-of-date state messages using the host's version counter.
 */
class GameClient(
    val host: String,
    val port: Int,
    val roomId: String,
    private val name: String,
    initialToken: String?,
    private val onUi: (UiState) -> Unit,
    private val onToast: (String) -> Unit,
    private val onSession: (String, Int) -> Unit,
    private val onEnded: () -> Unit
) {
    @Volatile
    var token: String? = initialToken
        private set

    @Volatile private var stopped = false
    @Volatile private var conn: Conn? = null
    private var ui = UiState(conn = ConnState.CONNECTING)
    private val io = Executors.newSingleThreadScheduledExecutor()
    private var thread: Thread? = null

    private fun update(f: (UiState) -> UiState) {
        val s = synchronized(this) { if (stopped) null else { ui = f(ui); ui } } ?: return
        onUi(s)
    }

    fun start() {
        io.scheduleAtFixedRate(Runnable { conn?.send(JSONObject().put("t", "ping")) }, 3, 3, TimeUnit.SECONDS)
        thread = Thread({ loop() }, "client-loop").apply { isDaemon = true; start() }
    }

    fun send(j: JSONObject) {
        if (stopped) return
        try { io.execute { conn?.send(j) } } catch (_: Exception) {}
    }

    fun stop() {
        stopped = true
        conn?.close()
        thread?.interrupt()
        io.shutdownNow()
    }

    /** Intentional leave: tell the host, then close. */
    fun leave() {
        stopped = true
        val c = conn
        try { io.execute { c?.send(JSONObject().put("t", "leave")); c?.close() } } catch (_: Exception) { c?.close() }
        io.shutdown()
        thread?.interrupt()
    }

    private fun finish(state: ConnState, msg: String) {
        update { it.copy(conn = state, notice = msg) }
        stopped = true
        conn?.close()
        io.shutdownNow()
        onEnded()
    }

    private fun loop() {
        var failures = 0
        while (!stopped) {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 4000)
                s.soTimeout = 9000
                s.tcpNoDelay = true
                s.keepAlive = true
                val c = Conn(s)
                conn = c
                val hello = JSONObject().put("t", "hello").put("room", roomId).put("name", name)
                token?.let { hello.put("token", it) }
                c.send(hello)
                val reader = s.getInputStream().bufferedReader(Charsets.UTF_8)
                while (!stopped) {
                    val line = reader.readLine() ?: break
                    val j = parseJson(line) ?: continue
                    when (j.optString("t")) {
                        "welcome" -> {
                            failures = 0
                            val tok = j.getString("token")
                            val seat = j.getInt("seat")
                            token = tok
                            update { it.copy(conn = ConnState.ONLINE, mySeat = seat, roomId = roomId, notice = "") }
                            onSession(tok, seat)
                        }
                        "state" -> applyState(j)
                        "error" -> onToast(j.optString("msg", "Not allowed."))
                        "reject" -> { finish(ConnState.REJECTED, j.optString("msg", "Could not join.")); return }
                        "closed" -> { finish(ConnState.HOST_LOST, "The host ended the game."); return }
                        else -> {}
                    }
                }
            } catch (e: Exception) {
                // fall through to reconnect handling
            }
            conn?.close()
            if (stopped) return
            if (token == null) {
                finish(ConnState.REJECTED, "Could not reach the host. Check that both phones are on the same Wi-Fi and the details are right.")
                return
            }
            failures++
            if (failures > 8) {
                finish(ConnState.HOST_LOST, "The host can no longer be reached.")
                return
            }
            update { it.copy(conn = ConnState.RECONNECTING) }
            try { Thread.sleep(2500) } catch (e: InterruptedException) { return }
        }
    }

    private fun applyState(j: JSONObject) {
        try {
            val v = j.getInt("v")
            val trumpStr = j.optString("trump", "")
            val trick = j.getJSONArray("trick").let { a ->
                List(a.length()) { i ->
                    val o = a.getJSONObject(i)
                    Play(o.getInt("s"), parseCard(o.getString("c"))!!)
                }
            }
            val hist = j.getJSONArray("hist").let { a -> List(a.length()) { RoundResult.fromJson(a.getJSONObject(it)) } }
            val hand = j.getJSONArray("hand").strs().mapNotNull { parseCard(it) }
            update { cur ->
                if (v <= cur.version) cur else cur.copy(
                    conn = ConnState.ONLINE, version = v,
                    phase = Phase.valueOf(j.getString("phase")),
                    round = j.getInt("round"), dealer = j.getInt("dealer"),
                    trump = if (trumpStr.isEmpty()) null else suitOf(trumpStr[0]),
                    turn = j.getInt("turn"),
                    names = j.getJSONArray("names").strs(),
                    seated = j.getJSONArray("seated").bools(),
                    connected = j.getJSONArray("conn").bools(),
                    pred = j.getJSONArray("pred").ints(),
                    tricks = j.getJSONArray("tricks").ints(),
                    total = j.getJSONArray("total").ints(),
                    roundScore = j.getJSONArray("rscore").ints(),
                    counts = j.getJSONArray("counts").ints(),
                    trick = trick, trickWinner = j.getInt("tw"),
                    paused = j.getBoolean("paused"),
                    hand = hand, history = hist
                )
            }
        } catch (e: Exception) {
            // malformed state message: ignore, next one will replace it
        }
    }
}
