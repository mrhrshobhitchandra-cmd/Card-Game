# Trump Cards – 4-player LAN prediction card game (Android)

Native Android app (Kotlin + Jetpack Compose). Four phones on the **same Wi-Fi** (or one phone's hotspot) play together.
No internet, no cloud, no external server. One phone hosts; the same APK is installed on all four.

> **Status: source complete, NOT yet compiled or tested on devices.** See `TESTING.md` for exactly what has and has not been verified.

## Getting the APK (GitHub, no Android Studio)
1. Create a free account at github.com and a new **public** repository.
2. Upload everything inside this folder (not the folder itself). Hidden folders may be skipped by the browser, so also create the file `.github/workflows/build.yml` by hand (contents are in `build.yml`).
3. Open the repository's **Actions** tab → wait for the green check (≈5–10 min) → open the run → download the **app-debug** artifact (zip) → unzip to get `app-debug.apk`. `app-release` is also built (signed with the debug key, so it installs too). The `test-report` artifact holds the engine unit-test results.
4. If the run shows a red ✗, open the failed step and send the error text back for a fix.

## Installing
Copy the APK to each phone (WhatsApp, Drive, USB). Tap it and allow "Install unknown apps" for that source once. Android 13+ asks for the "Nearby devices" permission on first launch: allow it (used for local-network discovery).

## Playing
- **Host:** Settings → set your name → Create Room. The lobby shows Room ID, IP and port.
- **Others:** Join Room → the room appears automatically (tap it). If not, use manual entry with the IP, port and room code shown on the host's lobby.
- When four players are connected, the host presses **Start Game**. Everyone locks in a prediction (0–13); then play. The host controls Play Again / Return to Lobby / End round (when a player is disconnected).
- Tap a card to select it, tap again (or press **Play**) to play it. Illegal cards are dimmed on your turn; tapping one explains why.

## Architecture
```
engine/   Deck, Rules (legal moves, trick winner, first leader), Scoring (single roundScore function) – pure Kotlin
net/      HostServer (authoritative state), GameClient (all players incl. host), Nsd (mDNS), Protocol (JSON lines)
ui/       Compose screens: Menu, Join, Lobby, Table, Results, Rules, Settings, History
```
- **Transport:** TCP, one JSON object per line, max 4 KB accepted per line, unknown/malformed messages ignored.
- **Authority:** the host validates turn order, card ownership and every rule (`Rules.validate`) and computes trick counts and scores; clients never report counts or scores.
- **Private cards:** each client receives a `state` message containing public data plus only its own hand. The host's own player connects to its server over loopback exactly like a remote client, so the host UI never gets other hands. (The host process necessarily holds the deck in memory; a modified app on the host phone could read it. This is inherent to a host-authoritative design without cryptographic dealing.)
- **Session tokens:** each seat gets a random 128-bit token at join. Reconnection (`hello` with token) restores the seat, hand and turn; unknown tokens are rejected. Joining requires the 4-character room code.
- **Versioning:** every state broadcast carries a monotonically increasing version; clients drop older versions.
- **Heartbeat:** ping every 3 s; read timeouts of 9 s (client) / 12 s (host) detect dead links. Clients retry every 2.5 s up to 8 times, then show "Host unavailable" (Keep trying / Back to menu).
- **Disconnect during play:** game pauses (moves rejected), "Paused – waiting for X" is shown, the host may end the round. Nothing is redealt or reset on reconnect.
- **Discovery:** NSD service `_trumpcards._tcp.` with TXT room/host/slots; the host re-advertises when free slots change.

## Known limitations / deviations from the brief
- Persistence uses **SharedPreferences** (name, settings, round history, last session for "Rejoin last game"), not Room/DataStore.
- Sounds are simple system tones; no custom audio assets or custom card artwork.
- Seating is clockwise: left of you plays after you, then across, then right.
- The screen is kept awake; there is no foreground service, so a host that backgrounds the app may lose connections on some phones.
- The host's own phone is the single point of failure: if the host app dies, the round is lost.
- Android 16+ local-network permission behaviour is untested (target SDK 34).
