# Testing report (honest status)

Nothing in this project has been compiled or run yet; it was written without access to a Kotlin compiler or Android device.

| # | Required test | Status |
|---|---|---|
| 14, 16, 17 (logic), 5 (deal) | Trick winner, all scoring cases incl. P=0, 52-card deal, follow-suit/trump/overtrump rules | Unit tests written (`app/src/test`), run automatically in GitHub Actions – **result not yet seen** |
| 1–4, 6–13, 15, 18–23 | Room creation, discovery, manual join, four-player sync, private hands, predictions, illegal-move rejection, full 13-trick game, reconnect, host loss, airplane-mode/no-internet, screen sizes | **Not tested** – must be checked on four phones |

Suggested manual script for four phones (Wi-Fi without internet, mobile data off): create room → auto-discover on 3 phones → one phone via manual IP → start → verify each phone sees only its own cards → try an illegal card → finish a round and compare scores with the Rules screen → toggle Wi-Fi on one phone mid-trick (expect pause, then resume with same hand) → close the host app (expect "Host unavailable").
